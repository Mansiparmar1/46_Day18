<?php
$x = 9;
$y = 4;
echo $x + $y;
?>
