<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $databasename = "std";

    $conn = mysqli_connect($servername, $username, $password,$databasename);
    if($conn -> connect_error)
    {
       
        die($conn -> connect_error);
    }
    else
    {
        echo "MySql Connection Successful!" . '<br/>';
    }

    $query = "INSERT INTO student(student_id, student_name, branch, addres) VALUES(101,'jyoti','computer','ahmedabad')";
    $query = "INSERT INTO student(student_id, student_name, branch, addres) VALUES(102,'prinshu','computer','ahmedabad')";
    $query = "INSERT INTO student(student_id, student_name, branch, addres) VALUES(103,'mansi','computer','ahmedabad')";
    $query = "INSERT INTO student(student_id, student_name, branch, addres) VALUES(104,'kimti','computer','ahmedabad')";
    $query = "INSERT INTO student(student_id, student_name, branch, addres) VALUES(105,'roshini','computer','ahmedabad')";
    $result = $conn->multi_query($query);
    // $query = "INSERT INTO student2(studentid, firstname, lastname, mnumber, email_id, addr, branch,  sem, createddate, uploaddate) VALUES('1', 'rima', 'shah', '9975486000', 'rs1@gmail.com', 'gandhinagar', 'IT', '4');";
   
    //$query = "INSERT INTO student2(studentid, firstname, lastname, mnumber, email_id, addr, branch,  sem, createddate, uploaddate) VALUES('2', 'rakesh', 'shah', '9975254600', 'rs1354@gmail.com', 'gandhinagar', 'CIVIL', '4');";

    $query = "UPDATE student SET student_name='prin' where student_id='102';";
    
     //$query = "DELETE FROM student2 "
    if($conn -> error)
    {
        echo $conn->error;
    }
    else
    {
        echo "Record Inserted successfully";
    }

   $query = "SELECT * FROM student";
    $result = $conn->query($query);

    if($conn -> error)
    {
        echo $conn->error;
    }
    else
    {
        echo '<br/>';
        while($row = $result->fetch_assoc())
        {
            echo '<pre/>';
            print_r($row);
            echo "HI" . $row["student_name"] . "" . ',';
            echo implode('|',$row) . '<br/>';
        }
    }
?>