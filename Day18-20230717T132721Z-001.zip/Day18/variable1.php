<?php
$txt = "Hello";
echo "How are you $txt";
?>